"""Export only selected source/menu; expert labels remain sealed."""
import importlib.util
import json
import shutil
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
spec = importlib.util.spec_from_file_location('curate', BASE/'curate.py')
curate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(curate)


def export(ids):
    grid = json.loads((BASE/'selection-grid.json').read_text())
    grid_hashes = {'selection-grid.json':curate.digest(BASE/'selection-grid.json')}
    for filename in ('selection-addendum-1.json','selection-addendum-2.json'):
        addition=json.loads((BASE/filename).read_text())
        grid['specs'].extend(addition['specs'])
        grid['source_manifests'].update(addition['source_manifests'])
        grid_hashes[filename]=curate.digest(BASE/filename)
    specs = {s['id']: s for s in grid['specs']}
    ids = sorted(ids,key=lambda case: grid['source_manifests'][case]['files']['default']['sha256'])
    destination = ROOT/'examples/p4-multirepair'
    manifest = {'schema_version':1, 'case_order':'baseline source SHA256 ascending; source-based, independent of oracle role', 'cases':[], 'curation_grid_sha256':curate.digest(BASE/'selection-grid.json'), 'curation_grid_hashes':grid_hashes, 'separation':'Independent curator source export. Selection uses annotation-only compiler qualification, never adviser or mechanical outcomes. Expert repair labels remain sealed until all policy choices complete.'}
    for i, original in enumerate(ids):
        case_id=f'heldout-{i+1:02}'
        record=grid['source_manifests'][original]
        case={'id':case_id, 'structure':specs[original]['structure'], 'requirements':record['requirements'], 'group_semantics':{'a':'eight independent side policy tables','b':'primary dependency/action graph tables'}, 'default':f'evaluation/{case_id}/default/program.p4', 'candidates':[]}
        base=(BASE/record['files']['default']['source']).read_text().splitlines()
        for name, info in record['files'].items():
            source=BASE/info['source']
            path=destination/'evaluation'/case_id/name/'program.p4'
            path.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(source,path)
            if name!='default':
                after=source.read_text().splitlines()
                edits=[{'line':line,'text':b.rstrip()} for line,(a,b) in enumerate(zip(base,after),1) if a!=b]
                assert all(not base[e['line']-1].strip() for e in edits)
                case['candidates'].append({'id':name,'source':str(path.relative_to(destination)), 'sha256':info['sha256'],'edits':edits})
        # Fixed grammar order independent of qualification order/outcomes.
        by_id={c['id']:c for c in case['candidates']}
        case['candidates']=[by_id[n] for n in curate.generator.POLICIES if n!='default']
        case['default_sha256']=record['files']['default']['sha256']
        manifest['cases'].append(case)
    from scripts.p4_multirepair_experiment import validate_manifest
    validate_manifest(manifest,destination)
    (destination/'corpus.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (BASE/'export-map.json').write_text(json.dumps(dict(zip([c['id'] for c in manifest['cases']],ids)),indent=2)+'\n')


if __name__=='__main__':
    selection=json.loads((BASE/'selection.json').read_text())
    assert selection['export_authorized']
    assert selection['qualification_complete'] or selection['status']=='v1_qualification_incomplete_smaller_corpus_prepared'
    export(selection['selected'])

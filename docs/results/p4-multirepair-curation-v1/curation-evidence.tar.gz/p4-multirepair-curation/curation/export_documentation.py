"""Describe exported source ancestry and aggregate effort without expert labels."""
import json
from pathlib import Path
from curate import ROOT, SEALED, digest

corpus=ROOT/'examples/p4-multirepair/corpus.json'
manifest=json.loads(corpus.read_text())
base=corpus.parent/'evaluation'
case_map=json.loads((SEALED/'export-map.json').read_text())
specs={}
for name in ['selection-grid.json','selection-addendum-1.json','selection-addendum-2.json']:
 specs.update({s['id']:s for s in json.loads((SEALED/name).read_text())['specs']})
lines=['# Exported source ancestry and groups','','This document describes source construction only. It contains no per-case compiler outcomes, repair labels, case roles or adviser choices. Case IDs are assigned by ascending SHA256 of baseline source bytes; they encode no qualification role.','','All sources are synthetic derivatives of the same public TNA parser/deparser and table scaffold in `examples/p4-fit/generate.py`. They are not independent production applications. New action, control and dependency graphs were constructed by the independent curator. Width or capacity changes within a graph are counted as one structure.','','Every source has eight side policy tables and twelve primary graph tables. Group **a** always means the eight side policy tables; group **b** always means all twelve primary graph tables. Groups were fixed by source semantics before any qualification. Every declared application table and its requested logical capacity appears in the manifest.','','The uniform menu contains 25 nondefault candidates plus the unannotated default. Each source uses four 80-character annotation slots per table. Alternatives retain `program.p4`, all source-line positions and every byte outside the declared slots. They are fresh alternatives, not cumulative edits.','','| Case | Source structure | Primary action/control dataflow |','|---|---|---|']
for case in manifest['cases']:
 spec=specs[case_map[case['id']]]
 if spec['structure']=='overlapping-admission':
  description='Twelve dependent token-rewrite lookups. Even/odd side-table subsets are admitted by distinct overlapping tenant-bit predicates (bits 0 and 2). Either, both or neither subset may execute.'
 elif spec['structure']=='accumulating-chain':
  coupled='action_parameter_coupling' in spec
  description='Twelve dependent lookups rewrite the token and accumulate an observable packet field. '+('One 32-bit action parameter supplies both updates.' if coupled else 'Independent 32-bit action parameters supply the token and accumulator updates.')
 else:
  description='Four repeated diamonds: two parallel token-keyed lookups produce separate fork fields; a join lookup keys on both fields and rewrites the token. Eight side lookups remain independent.'
 lines.append(f"| {case['id']} | {case['structure']} | {description} |")
lines+=['','All packet results are emitted. The source construction and annotation-only checks do not establish executed packet equivalence, hardware performance or production generalization. Compiler qualification and adviser evaluation are separate evidence.','','The initial curation grid and two prospective addenda are identified by SHA256 in `curation-metadata.json`. Original failed, interrupted and excluded searches remain retained in the sealed evidence ledger. Expert outcomes remain sealed until all adviser choices finish.','']
(base/'ANCESTRY.md').write_text('\n'.join(lines))
ledger=json.loads((SEALED/'curation-ledger.json').read_text())
selection=json.loads((SEALED/'selection.json').read_text())
metadata={'schema_version':1,'qualification_status':selection['status'],'initial_v1_target':{'repair_cases':6,'repair_structures':3,'distinct_mechanisms':2,'default_fit_controls':1,'no_known_repair_controls':1},'aggregate_qualified':selection['aggregate_qualified'],'case_roles_and_expert_answers':'withheld until all adviser choices complete','source_case_count':len(manifest['cases']),'source_variant_count':26*len(manifest['cases']),'case_order':'baseline source SHA256 ascending','curation_grid_hashes':ledger['grid_hashes'],'curation_cost':ledger['cost'],'initial_acceptance_runner_sha256':'fa52166cea623f0e972632fed73c419a57125f4588904aed7e0123ed551a681b','current_acceptance_runner_sha256':'bf1451bc2dea88fabebabd609304ba1c0504e6903e648dd70a8e85fa3e42933e','compiler_image':'sha256:5b27c37f3835c646c4a7f87c64de986a5fd5d71170b3f8b91e4bfbb908763af9','timeout_seconds':120,'interpretation':'Synthetic compiler-reported resource-fit qualification, with full declared capacities and BFRT gate. No hardware execution or generalization claim. No adviser calls in curation. V1 must not be evaluated when qualification is incomplete; a smaller pilot requires its own pre-call freeze.'}
(base/'curation-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print({'manifest_sha256':digest(corpus),'ancestry_sha256':digest(base/'ANCESTRY.md'),'metadata_sha256':digest(base/'curation-metadata.json')})

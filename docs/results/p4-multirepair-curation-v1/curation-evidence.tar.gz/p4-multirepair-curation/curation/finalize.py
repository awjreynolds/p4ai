"""Close bounded curation and export only a qualified source-only corpus."""
import json
import re
from pathlib import Path
from curate import SEALED, generator, digest

menus=set(generator.POLICIES)
for name in ('boundary-05','boundary-07','control-unsolved'):
 observed={p.parent.name for p in (SEALED/'compiles'/name).glob('*/probe.json')}
 has_repair=any(json.loads(p.read_text())['accepted'] for p in (SEALED/'compiles'/name).glob('*/audit-bf1451bc.json') if p.parent.name!='default')
 assert observed==menus or (name!='control-unsolved' and has_repair), (name,sorted(menus-observed))
for name in [f'boundary-{i:02}' for i in range(1,9)]:
 assert (SEALED/'compiles'/name/'default/probe.json').exists()
assert json.loads((SEALED/'compiles/control-fit/default/audit-bf1451bc.json').read_text())['accepted']
assert not any(json.loads(p.read_text())['accepted'] for p in (SEALED/'compiles/control-unsolved').glob('*/audit-bf1451bc.json'))
assert 'supports up to 12 stages' in (SEALED/'compiles/control-unsolved/default/stderr.log').read_text()

repair_cases=['candidate-01','candidate-02','extension-01','extension-02']
for name in repair_cases:
 base=json.loads((SEALED/'compiles'/name/'default/audit-bf1451bc.json').read_text())
 assert not base['compiler_fit'] and base['audit']['eligible_fit']
 assert 'supports up to 12 stages' in (SEALED/'compiles'/name/'default/stderr.log').read_text()
 assert any(json.loads(p.read_text())['accepted'] for p in (SEALED/'compiles'/name).glob('*/audit-bf1451bc.json') if p.parent.name!='default')

third=[]
for name in [f'boundary-{i:02}' for i in range(1,9)]:
 base=json.loads((SEALED/'compiles'/name/'default/audit-bf1451bc.json').read_text())
 if not base['compiler_fit'] and base['audit']['eligible_fit'] and any(json.loads(p.read_text())['accepted'] for p in (SEALED/'compiles'/name).glob('*/audit-bf1451bc.json') if p.parent.name!='default'):
  third.append(name)
complete=len(third)>=2
selected=repair_cases+(third[:2] if complete else [])+['control-fit','control-unsolved']
result={'status':'v1_qualified' if complete else 'v1_qualification_incomplete_smaller_corpus_prepared','qualification_complete':complete,'export_authorized':True,'selected':selected,'aggregate_qualified':{'repair_cases':6 if complete else 4,'repair_structures':3 if complete else 2,'distinct_mechanisms':2,'default_fit_controls':1,'no_known_repair_controls':1},'third_structure_qualified_cases':third,'reason':'The bounded third-structure grid completed. Baseline-fitting points are not repair cases, and no unaccepted/timeout/interrupted result counts as repair. V1 requires six repairs across three repair structures. A smaller corpus is exported only under coordinator authorization for a separately frozen pilot; no adviser calls occurred.','expert_answers_release':'Not authorized until coordinator confirms all adviser choices complete.'}
(SEALED/'selection.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'selected','third_structure_qualified_cases'}}))

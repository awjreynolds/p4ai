"""Follow the frozen ascending-source qualification search; never consume adviser output."""
import json
import re
import sys
from pathlib import Path
from curate import SEALED, ORDER, probe


def receipt(case,candidate):
    p=SEALED/'compiles'/case/candidate/'audit.json'
    return json.loads(p.read_text()) if p.exists() else None


def ensure(case,candidate):
    result=receipt(case,candidate)
    if result is None:
        probe(case,candidate)
        result=receipt(case,candidate)
    return result


selected=[]
for number in map(int,sys.argv[1:]):
    case=f'candidate-{number:02}'
    base=ensure(case,'default')
    stderr=(SEALED/'compiles'/case/'default'/'stderr.log').read_text()
    resource_failure=not base['compiler_fit'] and base['audit']['eligible_fit'] and base['returncode']==2 and bool(re.search(r'supports up to 12 stages|resources? exceeded|could not place',stderr,re.I))
    if not resource_failure:
        state={'case':case,'qualified':False,'reason':'baseline_not_verified_resource_failure'}
    else:
        state={'case':case,'qualified':False,'reason':'menu_exhausted'}
        for candidate in ORDER:
            result=ensure(case,candidate)
            if result['accepted']:
                state={'case':case,'qualified':True,'repair':candidate}
                selected.append(case)
                break
    path=SEALED/'qualification'/f'{case}.json'
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(state,indent=2)+'\n')
    print(json.dumps(state),flush=True)
    if len(selected)>=2:
        break

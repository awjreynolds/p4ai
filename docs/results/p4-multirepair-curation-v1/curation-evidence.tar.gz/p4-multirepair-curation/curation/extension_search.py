import json
import re
from curate import SEALED, ORDER
from extension_probe import probe
selected=[]
for n in range(1,5):
    case=f'extension-{n:02}'
    base=probe(case,'default')
    text=(SEALED/'compiles'/case/'default/stderr.log').read_text()
    valid=not base['compiler_fit'] and base['audit']['eligible_fit'] and base['returncode']==2 and 'supports up to 12 stages' in text
    state={'case':case,'qualified':False,'reason':'baseline_not_verified_resource_failure' if not valid else 'menu_exhausted'}
    if valid:
        for candidate in ORDER:
            result=probe(case,candidate)
            if result['accepted']:
                state={'case':case,'qualified':True,'repair':candidate}
                selected.append(case)
                break
    (SEALED/'qualification'/f'{case}.json').write_text(json.dumps(state,indent=2)+'\n')
    print(json.dumps(state),flush=True)
    if len(selected)==2:
        break

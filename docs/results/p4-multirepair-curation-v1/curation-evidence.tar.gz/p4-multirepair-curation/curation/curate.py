"""Independent deterministic held-out source and qualification curation."""
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SEALED = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts.p4_compile_probe import compile_case
from scripts.p4_multirepair_experiment import acceptance


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


scaffold = load_module('scaffold', ROOT / 'examples/p4-fit/generate.py')
generator = load_module('generator', ROOT / 'examples/p4-multirepair/generate.py')
IMAGE = 'sha256:5b27c37f3835c646c4a7f87c64de986a5fd5d71170b3f8b91e4bfbb908763af9'
ORDER = ['a-no-immediate', 'a-pack-3', 'a-pack-2', 'a-pack-4'] + sorted(set(generator.POLICIES) - {'default', 'a-no-immediate', 'a-pack-3', 'a-pack-2', 'a-pack-4'})


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def render(spec, policy):
    source = scaffold.render({'depth': 12, 'sides': 8, 'chain_entries': spec.get('chain_entries', 16384), 'side_entries': spec['entries'], 'tenant_bits': spec['tenant_bits'], 'stable_layout': True}, {'side' if group == 'a' else 'chain': value for group, value in policy.items()})
    structure = spec['structure']
    if structure == 'overlapping-admission':
        for i in range(8):
            bit = (0 if i % 2 == 0 else 2)
            source = source.replace(f'            side_{i}.apply();', f'            if ((hdr.fit.tenant & {spec["tenant_bits"]}w{1 << bit}) != 0) {{ side_{i}.apply(); }}')
    elif structure == 'accumulating-chain':
        source = source.replace('    bit<32> token;', '    bit<32> token;\n    bit<32> accumulator;')
        for i in range(12):
            source = source.replace(f'action set_chain_{i}(bit<32> value) {{ hdr.fit.token = value; }}', f'action set_chain_{i}(bit<32> value, bit<32> delta) {{ hdr.fit.token = value; hdr.fit.accumulator = hdr.fit.accumulator + delta; }}')
    elif structure == 'fork-join-chain':
        source = source.replace('    bit<32> token;', '    bit<32> token;\n    bit<32> fork_left;\n    bit<32> fork_right;')
        for i in range(12):
            if i % 3 < 2:
                field = 'fork_left' if i % 3 == 0 else 'fork_right'
                source = source.replace(f'action set_chain_{i}(bit<32> value) {{ hdr.fit.token = value; }}', f'action set_chain_{i}(bit<32> value) {{ hdr.fit.{field} = value; }}')
            else:
                source = source.replace(f'table chain_{i} {{\n        key = {{ hdr.fit.token : exact; }}', f'table chain_{i} {{\n        key = {{ hdr.fit.fork_left : exact; hdr.fit.fork_right : exact; }}')
    else:
        raise ValueError(structure)
    required = {**{f'Ingress.chain_{i}': spec.get('chain_entries',16384) for i in range(12)}, **{f'Ingress.side_{i}': spec['entries'] for i in range(8)}}
    return source, required


def initialize():
    specs = []
    for structure in ('overlapping-admission', 'accumulating-chain', 'fork-join-chain'):
        for width, capacities in ((8, (196608, 180224)), (48, (114688, 131072)), (64, (114688, 98304))):
            for entries in capacities:
                specs.append({'id': f'candidate-{len(specs)+1:02}', 'structure': structure, 'tenant_bits': width, 'entries': entries})
    specs += [{'id': 'control-fit', 'structure': 'fork-join-chain', 'tenant_bits': 16, 'entries': 1024, 'chain_entries': 1024}, {'id': 'control-unsolved', 'structure': 'accumulating-chain', 'tenant_bits': 64, 'entries': 524288, 'chain_entries': 32768}]
    document = {'schema_version': 1, 'specs': specs, 'selection_rule': 'In ascending candidate number, select earliest two accepted baseline-failing cases per structure. Baseline failure must have context, verified BFRT/capacity and a compiler resource-stage/capacity diagnostic, not parse/error/timeout. A qualifying repair is compiler success plus full acceptance. Search development-informed prefix in declared order, then all remaining menu entries until an accepted repair; if only one distinct mechanism is represented, continue remaining menu on qualifying cases in ascending ID until second mechanism or exhaustion. Preserve all sources/attempts/exclusions. Controls qualify by baseline success or baseline real-resource failure plus exhaustive all25 nondefault failures. Never substitute based on strategy/adviser outcomes. Stop evaluation preparation if six repairs/three structures/two mechanisms cannot be obtained. Additional grids require separately hashed addendum before any new compile and retain original grid.', 'candidate_search_order': ORDER, 'menu': generator.POLICIES, 'semantic_groups': {'a': 'eight side policy tables', 'b': 'twelve primary graph tables'}, 'ancestry': {'description': 'All three derive common TNA parser/deparser and table scaffold. Overlapping-admission changes admission predicates versus published development (even/odd side assignment, tenant bits0/2); accumulating-chain adds an observable independently parameterized accumulator update at every dependent step; fork-join-chain replaces the12-table token chain by four parallel-fork/join diamonds, retaining all8 independent side outputs. These are three synthetic action/control/dependency structures with common ancestry, not unrelated applications.', 'sources': {str(p.relative_to(ROOT)): digest(p) for p in (ROOT/'examples/p4-fit/generate.py', ROOT/'examples/p4-multirepair/generate.py', ROOT/'examples/p4-multirepair/development.md', Path(__file__))}}, 'compiler_image': IMAGE, 'timeout_seconds': 120, 'initial_plan': {'source_cases': len(specs), 'candidate_sources_per_case': 26, 'maximum_compiles':len(specs)*26,'reassess_after_compiles':40}, 'separation': 'Procedural only: common filesystem has no ACL boundary. Curator did not read mechanical policy, policy discussion or adviser responses. No adviser calls in curation.'}
    path = SEALED/'selection-grid.json'
    if path.exists():
        raise ValueError('selection grid already frozen')
    for spec in specs:
        base, required = render(spec,{})
        files = {}
        for name, policy in generator.POLICIES.items():
            source, capacities = render(spec,policy)
            assert capacities == required and scaffold.blank_annotations(source) == base
            assert len(source) == len(base) and len(source.splitlines()) == len(base.splitlines())
            path_source = SEALED/'sources'/spec['id']/name/'program.p4'
            path_source.parent.mkdir(parents=True)
            path_source.write_text(source)
            files[name] = {'source': str(path_source.relative_to(SEALED)), 'sha256': digest(path_source)}
        document.setdefault('source_manifests',{})[spec['id']] = {'requirements':required,'files':files}
    path.write_text(json.dumps(document,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'grid_sha256':digest(path),'planned_source_cases':len(specs),'maximum_compiles':len(specs)*26}))


def probe(case_id, candidate):
    grid = json.loads((SEALED/'selection-grid.json').read_text())
    record = grid['source_manifests'][case_id]
    source = SEALED/record['files'][candidate]['source']
    assert digest(source) == record['files'][candidate]['sha256']
    output = SEALED/'compiles'/case_id/candidate
    if (output/'probe.json').exists():
        report = json.loads((output/'probe.json').read_text())
    else:
        report = compile_case(source, output, IMAGE,120)
    audit = acceptance(record, output, SEALED/'compiles'/case_id/'default')
    result = {'case':case_id,'candidate':candidate,'compiler_fit':report['compiler_reported_fit'],'accepted':report['compiler_reported_fit'] and audit['eligible_fit'],'audit':audit,'returncode':report['returncode'],'seconds':report['elapsed_seconds'],'probe_sha256':digest(output/'probe.json')}
    (output/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'initialize':
        initialize()
    else:
        probe(sys.argv[1],sys.argv[2])

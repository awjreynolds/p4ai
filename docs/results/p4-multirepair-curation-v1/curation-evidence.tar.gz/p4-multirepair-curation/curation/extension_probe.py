"""Compile only sources frozen in selection-addendum-1."""
import json
import sys
from curate import SEALED, IMAGE, digest, compile_case, acceptance


def probe(case_id,candidate):
    grid=json.loads((SEALED/'selection-addendum-1.json').read_text())
    record=grid['source_manifests'][case_id]
    source=SEALED/record['files'][candidate]['source']
    assert digest(source)==record['files'][candidate]['sha256']
    output=SEALED/'compiles'/case_id/candidate
    if (output/'probe.json').exists():
        report=json.loads((output/'probe.json').read_text())
    else:
        report=compile_case(source,output,IMAGE,120)
    audit=acceptance(record,output,SEALED/'compiles'/case_id/'default')
    result={'case':case_id,'candidate':candidate,'compiler_fit':report['compiler_reported_fit'],'accepted':report['compiler_reported_fit'] and audit['eligible_fit'],'audit':audit,'returncode':report['returncode'],'seconds':report['elapsed_seconds'],'probe_sha256':digest(output/'probe.json')}
    (output/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    return result


if __name__=='__main__':
    for candidate in sys.argv[2:]:
        probe(sys.argv[1],candidate)

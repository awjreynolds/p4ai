"""Replay the intended fail-closed allocation-identity gate without recompilation."""
import json
from pathlib import Path
from curate import SEALED, ROOT, digest
from scripts.p4_multirepair_experiment import acceptance

OLD=json.loads((SEALED/'qualification-code-identities.json').read_text())['files']['scripts/p4_multirepair_experiment.py']
NEW='bf1451bc2dea88fabebabd609304ba1c0504e6903e648dd70a8e85fa3e42933e'
assert digest(ROOT/'scripts/p4_multirepair_experiment.py')==NEW
records={}
for name in ['selection-grid.json','selection-addendum-1.json','selection-addendum-2.json']:
 records.update(json.loads((SEALED/name).read_text())['source_manifests'])
rows=[]
for p in sorted((SEALED/'compiles').glob('*/*/probe.json')):
 case,candidate=p.parent.parent.name,p.parent.name
 report=json.loads(p.read_text());old=json.loads((p.parent/'audit.json').read_text())
 audit=acceptance(records[case],p.parent,SEALED/'compiles'/case/'default')
 row={'case':case,'candidate':candidate,'original_runner_sha256':OLD,'runner_sha256':NEW,'probe_sha256':digest(p),'original_audit_sha256':digest(p.parent/'audit.json'),'compiler_fit':report['compiler_reported_fit'],'accepted':bool(report['compiler_reported_fit'] and audit['eligible_fit']),'audit':audit,'original_accepted':old['accepted'],'acceptance_changed':old['accepted']!=bool(report['compiler_reported_fit'] and audit['eligible_fit'])}
 (p.parent/'audit-bf1451bc.json').write_text(json.dumps(row,indent=2)+'\n')
 rows.append(row)
result={'original_runner_sha256':OLD,'revised_runner_sha256':NEW,'purpose':'Implement the already-declared missing/duplicate allocation fail-closed requirement using nonnegative integer stage_number+logical_table_id and unique within-table tuples. No compiler reruns, policy/adviser changes or earlier experiment rescoring. Original receipts and audits retained.','completed_receipts_replayed':len(rows),'accepted_status_changes':sum(r['acceptance_changed'] for r in rows),'rows':rows}
(SEALED/'acceptance-replay-bf1451bc.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'}))

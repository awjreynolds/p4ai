"""Execute a declared subset of sealed candidate probes without adaptive policy inputs."""
import sys
from curate import probe
for candidate in sys.argv[2:]:
    probe(sys.argv[1], candidate)

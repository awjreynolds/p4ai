"""Package only curator-owned and explicitly shared evidence; never open evaluation arms."""
from pathlib import Path
import ast, collections, gzip, hashlib, json, re, shutil
ROOT=Path(__file__).resolve().parents[3]
SEALED=ROOT/'artifacts/p4-multirepair-curation/sealed'
OUT=SEALED/'release-bundle'
OUT.mkdir(exist_ok=True)
index=[]
def digest(b): return hashlib.sha256(b).hexdigest()
def write(name,obj):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def copy(p,name=None,compress=False):
 raw=p.read_bytes();data=raw
 if p.suffix!='.bin':
  data=data.replace(str(ROOT).encode(),b'${REPO}')
  if p.name=='interruption.json':
   obj=json.loads(data)
   if isinstance(obj.get('docker_inspect'),dict):
    d=obj['docker_inspect'];obj['docker_inspect']={k:d[k] for k in ['Created','Path','Args','State','Image'] if k in d}
    obj['docker_inspect']['State'].pop('Pid',None)
    obj['sanitization']='Host Docker metadata and environment omitted; original file hash retained in inventory.'
    data=(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode()
  assert not re.search(rb'/Users/[A-Za-z0-9_.-]+/',data), str(p)
 name=name or str(p.relative_to(ROOT))
 target=OUT/(name+('.gz' if compress else ''));target.parent.mkdir(parents=True,exist_ok=True)
 saved=gzip.compress(data,compresslevel=6,mtime=0) if compress else data
 target.write_bytes(saved)
 index.append({'path':str(target.relative_to(OUT)),'original_path':str(p.relative_to(ROOT)), 'original_sha256':digest(raw),'content_sha256':digest(data),'stored_sha256':digest(saved),'original_bytes':len(raw),'stored_bytes':len(saved),'sanitized':raw!=data,'gzip':compress})
 return str(target.relative_to(OUT))
# Exact generation contracts and the recorded acceptance revisions are kept, including unsuccessful sources.
for p in sorted(SEALED.iterdir()):
 if p.is_file() and p.suffix in ('.json','.py') and p.name!='bundle-readiness.json': copy(p,'curation/'+p.name)
for sub in ('sources','qualification','code-snapshots'):
 for p in sorted((SEALED/sub).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:copy(p,'curation/'+str(p.relative_to(SEALED)))
for p in sorted((SEALED/'compiles').rglob('*')):
 if p.is_file() and (p.name in {'probe.json','audit.json','audit-bf1451bc.json','interruption.json','stdout.log','stderr.log','manifest.json','bfrt.json','context.json','tofino.bin','table_summary.log'}):
  copy(p,'curation/'+str(p.relative_to(SEALED)),compress=p.name=='context.json')
for rel in ['examples/p4-multirepair/corpus.json','examples/p4-multirepair/development.md','examples/p4-multirepair/GENERATOR_API.md','examples/p4-multirepair/generate.py','examples/p4-fit/generate.py','examples/p4-immediate-dev/README.md','examples/p4-immediate-dev/qualification.json','scripts/p4_compile_probe.py','scripts/p4_fit_experiment.py']:
 copy(ROOT/rel)
for p in sorted((ROOT/'examples/p4-multirepair/evaluation').rglob('*')):
 if p.is_file():copy(p)
# Development is separate accounting; include receipts/source availability, never selectors.
devpath=ROOT/'artifacts/p4-multirepair-curation/development-search-summary.json'
copy(devpath)
dev=json.loads(devpath.read_text());devrows=[]
for row in dev['rows']:
 p=ROOT/row['probe'];copy(p);pr=json.loads(p.read_text())
 for n in ['stdout.log','stderr.log']:
  f=p.parent/n
  if f.exists():copy(f)
 source=p.parent.parent.parent/row['source']['file']
 available=source.exists() and digest(source.read_bytes())==row['source']['sha256']
 if available:copy(source)
 devrows.append({'probe':row['probe'],'elapsed_seconds':pr['elapsed_seconds'],'source_sha256':row['source']['sha256'],'historical_source_matches_available_file':available})
helper=[]
for p in sorted((ROOT/'artifacts/p4-immediate-dev/overlapping-admission-196608').glob('*/probe.json')):
 copy(p);pr=json.loads(p.read_text());helper.append({'probe':str(p.relative_to(ROOT)),'elapsed_seconds':pr['elapsed_seconds']})
 for n in ['stdout.log','stderr.log']:
  f=p.parent/n
  if f.exists():copy(f)
write('development-accounting.json',{'initial_development':{'physical_invocations':len(devrows),'aggregate_seconds':sum(x['elapsed_seconds'] for x in devrows),'receipts':devrows},'immediate_helper':{'physical_invocations':len(helper),'aggregate_seconds':sum(x['elapsed_seconds'] for x in helper),'receipts':helper},'note':'Separate from curation and evaluation. Historical overwritten development sources are explicitly marked unavailable.'})
grids=[json.loads((SEALED/n).read_text()) for n in ['selection-grid.json','selection-addendum-1.json','selection-addendum-2.json']]
manifests={k:v for g in grids for k,v in g['source_manifests'].items()}
ledger=json.loads((SEALED/'curation-ledger.json').read_text());mapping=json.loads((SEALED/'export-map.json').read_text())
exclusions=[]
for case in sorted(manifests):
 attempts=[a for a in ledger['attempts'] if a['case']==case]
 if case in mapping.values():reason='Selected for separately identified six-case corpus.'
 elif case.startswith('boundary-'):
  baseline=next(a for a in attempts if a['candidate']=='default')
  reason='Baseline fits; ineligible as a repair case.' if baseline['accepted'] else 'Failing baseline; all 25 candidates exhausted without accepted repair.'
 elif case.startswith('extension-') or case in ['candidate-03','candidate-04','candidate-05','candidate-06']:reason='Earlier two qualifying sources filled structural quota; remaining cells unqualified.'
 elif int(case.split('-')[1])<=12:reason='Superseded prospectively by addendum 1; partial search retained without infeasibility claim.'
 else:reason='Superseded prospectively by addendum 2; partial search retained without infeasibility claim.'
 tried={a['candidate'] for a in attempts}
 exclusions.append({'case':case,'selected':case in mapping.values(),'reason':reason,'attempts':len(attempts),'completed':sum(a['status']=='completed' for a in attempts),'unattempted_candidates':sorted(set(manifests[case]['files'])-tried)})
write('selection-and-exclusions.json',exclusions)
# Extract only the schema normalization function, never execute full runner code.
tree=ast.parse((SEALED/'code-snapshots/acceptance-stage-identity-runner.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='canonical_schema')
ns={'json':json};exec(compile(ast.Module(body=[fn],type_ignores=[]),'canonical_schema','exec'),ns)
canonical=ns['canonical_schema']
witnesses=[]
for public,case in mapping.items():
 qpath=SEALED/'qualification'/f'{case}.json'
 q=json.loads(qpath.read_text()) if qpath.exists() else {}
 repair=q.get('repair');role='repair' if repair else ('default_fit' if case=='control-fit' else 'no_known_repair')
 cells=[]
 for candidate in ['default']+([repair] if repair else []):
  d=SEALED/'compiles'/case/candidate
  probe=json.loads((d/'probe.json').read_text());audit=json.loads((d/'audit-bf1451bc.json').read_text())
  tables={t['name']:t for p in d.rglob('context.json') for t in json.loads(p.read_text()).get('tables',[])}
  capacity=[]
  for name,required in manifests[case]['requirements'].items():
   t=tables.get(name,{});stages=t.get('match_attributes',{}).get('stage_tables',[])
   capacity.append({'name':name,'required':required,'logical_size':t.get('size'),'allocated_size':sum(s.get('size',0) for s in stages),'stages':[{k:s.get(k) for k in ['stage_number','logical_table_id','stage_table_type','size']} for s in stages]})
  bfrt=json.loads((d/'compiler/bfrt.json').read_text())
  cells.append({'candidate':candidate,'source_sha256':digest((SEALED/manifests[case]['files'][candidate]['source']).read_bytes()),'probe_sha256':digest((d/'probe.json').read_bytes()),'accepted':audit['accepted'],'compiler_fit':probe['compiler_reported_fit'],'returncode':probe['returncode'],'canonical_bfrt_sha256':digest(json.dumps(canonical(bfrt),sort_keys=True,separators=(',',':')).encode()),'capacity':capacity})
 witnesses.append({'public_id':public,'curator_id':case,'role':role,'verified_witness':repair,'requirements':manifests[case]['requirements'],'cells':cells,'oracle_scope':'A verified witness, not proof of unique repair; only no-known-repair control exhausts all candidates.'})
write('expert-witnesses.json',witnesses)
write('inventory.json',index)
print(json.dumps({'files':len(index),'stored_bytes':sum(x['stored_bytes'] for x in index),'original_bytes':sum(x['original_bytes'] for x in index),'contexts':sum(x['gzip'] for x in index),'dev_source_unavailable':sum(not x['historical_source_matches_available_file'] for x in devrows)}))

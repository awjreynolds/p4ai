"""Separately identified curation extension; original source grid is immutable."""
import json
from pathlib import Path
from curate import SEALED, ROOT, generator, scaffold, render, digest

specs=[{'id':f'extension-{i+1:02}','structure':'accumulating-chain','tenant_bits':width,'entries':entries,'action_parameter_coupling':'one shared32-bit parameter updates token and accumulating observable value'} for i,(width,entries) in enumerate([(8,196608),(8,180224),(48,114688),(64,114688)])]
record={'schema_version':1,'parent_grid_sha256':digest(SEALED/'selection-grid.json'),'name':'shared-action-parameter-extension','rationale':'Original independently parameterized accumulating action increases per-step action-data geometry and is not yielding a near-boundary repair in initial probes. This separately identified new workload shares its32-bit action parameter between token and accumulator updates. It remains a distinct accumulating-action structure, with a new explicit workload semantics chosen before qualification. No capacity reductions occur within candidates. Original sources and failures remain retained; this does not relabel them as repaired.','selection_rule':'This extension replaces ONLY the accumulating-action contribution to final corpus selection: select earliest two qualified baseline-resource-failing source cases among extension01..04, searching original declared candidate_search_order and stopping at first accepted repair. Original candidate07..12 are retained as unsuccessful/incomplete discovery and excluded from final selection independent of any later outcome. Other original structure selection rules, the6+1+1 target, three-structure requirement, two-mechanism requirement and full menu remain unchanged. No strategy outcomes may enter curation. If the extension fails, report or separately identify another batch before compilation.','specs':specs,'candidate_search_order':json.loads((SEALED/'selection-grid.json').read_text())['candidate_search_order'],'menu':generator.POLICIES,'source_generator_sha256':digest(Path(__file__)),'ancestry_generator_sha256':digest(SEALED/'curate.py'),'plan':{'fresh_source_cases':4,'candidate_sources_per_case':26,'maximum_new_compiles':104},'source_manifests':{}}
for spec in specs:
    files={}
    for name,policy in generator.POLICIES.items():
        source,required=render(spec,policy)
        for i in range(12):
            source=source.replace(f'action set_chain_{i}(bit<32> value, bit<32> delta) {{ hdr.fit.token = value; hdr.fit.accumulator = hdr.fit.accumulator + delta; }}',f'action set_chain_{i}(bit<32> value) {{ hdr.fit.token = value; hdr.fit.accumulator = hdr.fit.accumulator + value; }}')
        if name=='default': baseline=source
        assert scaffold.blank_annotations(source)==baseline
        path=SEALED/'sources'/spec['id']/name/'program.p4'
        path.parent.mkdir(parents=True)
        path.write_text(source)
        files[name]={'source':str(path.relative_to(SEALED)),'sha256':digest(path)}
    record['source_manifests'][spec['id']]={'requirements':required,'files':files}
path=SEALED/'selection-addendum-1.json'
assert not path.exists()
path.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({'addendum_sha256':digest(path),'fresh_cases':4,'maximum_compiles':104}))

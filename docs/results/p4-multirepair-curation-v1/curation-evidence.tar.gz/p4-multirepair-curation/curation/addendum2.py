"""Prospective bounded resource-boundary grid for the fork/join structure."""
import json
from pathlib import Path
from curate import SEALED, generator, scaffold, render, digest

params=[(8,188416,16384),(8,192512,16384),(8,196608,8192),(48,122880,16384),(48,126976,16384),(64,106496,16384),(64,110592,16384),(8,196608,4096)]
specs=[{'id':f'boundary-{i+1:02}','structure':'fork-join-chain','tenant_bits':w,'entries':n,'chain_entries':c} for i,(w,n,c) in enumerate(params)]
record={'schema_version':1,'name':'fork-join-resource-boundary-extension','parent_grid_sha256':digest(SEALED/'selection-grid.json'),'prior_addendum_sha256':digest(SEALED/'selection-addendum-1.json'),'rationale':'Original fork/join baselines include a fitting lower-pressure point and one-stage-overflow higher-pressure points; first broad annotation searches have not repaired the selected higher points. This independently frozen grid samples intermediate entry geometry and smaller primary-graph table demands as NEW workloads. These dimensions are fixed before qualification and never change within a repair. This targets annotation-sensitive boundary behavior rather than exhaustively repeating broad failures.','selection_rule':'Replace ONLY original fork/join contribution: select earliest two baseline-resource-failing cases among boundary01..08 with an accepted annotation-only repair. Search original candidate order and stop at first accepted repair. Original candidate13..18 are retained as unsuccessful/incomplete discovery and excluded from final selection independent of any later outcome. Other contribution selection,6+1+1 target,3structures,2mechanisms, full25-candidate menu and all acceptance rules remain unchanged. If fewer than two qualify, do not weaken the contract.','specs':specs,'candidate_search_order':json.loads((SEALED/'selection-grid.json').read_text())['candidate_search_order'],'menu':generator.POLICIES,'source_generator_sha256':digest(Path(__file__)),'ancestry_generator_sha256':digest(SEALED/'curate.py'),'plan':{'fresh_source_cases':8,'candidate_sources_per_case':26,'maximum_new_compiles':208},'source_manifests':{}}
for spec in specs:
 files={}
 for name,policy in generator.POLICIES.items():
  source,required=render(spec,policy)
  if name=='default': baseline=source
  assert scaffold.blank_annotations(source)==baseline
  p=SEALED/'sources'/spec['id']/name/'program.p4';p.parent.mkdir(parents=True);p.write_text(source)
  files[name]={'source':str(p.relative_to(SEALED)),'sha256':digest(p)}
 record['source_manifests'][spec['id']]={'requirements':required,'files':files}
p=SEALED/'selection-addendum-2.json';assert not p.exists();p.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({'addendum_sha256':digest(p),'fresh_cases':8,'maximum_compiles':208}))

// SPDX-License-Identifier: MIT
// Generated discovery candidate. Resource fit has not been established.
#include <core.p4>
#if __TARGET_TOFINO__ == 2
#include <t2na.p4>
#else
#include <tna.p4>
#endif

header ethernet_t { bit<48> dst; bit<48> src; bit<16> ether_type; }
header fit_t {
    bit<32> token;
    bit<56> tenant;
    bit<32> result0;
    bit<32> result1;
    bit<32> result2;
    bit<32> result3;
    bit<32> result4;
    bit<32> result5;
    bit<32> result6;
    bit<32> result7;
    bit<8> branch;
    bit<24> reserved;
}
struct headers_t { ethernet_t ethernet; fit_t fit; }
struct metadata_t { }

parser IngressParser(packet_in pkt, out headers_t hdr, out metadata_t md,
                     out ingress_intrinsic_metadata_t ig_intr_md) {
    state start {
        pkt.extract(ig_intr_md);
        transition select(ig_intr_md.resubmit_flag) { 0: port_metadata; default: reject; }
    }
    state port_metadata { pkt.advance(PORT_METADATA_SIZE); transition ethernet; }
    state ethernet {
        pkt.extract(hdr.ethernet);
        transition select(hdr.ethernet.ether_type) { 16w0x88b5: fit; default: accept; }
    }
    state fit { pkt.extract(hdr.fit); transition accept; }
}

control Ingress(inout headers_t hdr, inout metadata_t md,
                in ingress_intrinsic_metadata_t ig_intr_md,
                in ingress_intrinsic_metadata_from_parser_t ig_prsr_md,
                inout ingress_intrinsic_metadata_for_deparser_t ig_dprsr_md,
                inout ingress_intrinsic_metadata_for_tm_t ig_tm_md) {
    action set_route_0_0(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_0 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_0; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_1(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_1 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_1; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_2(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_2 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_2; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_3(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_3 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_3; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_4(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_4 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_4; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_5(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_5 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_5; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_6(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_6 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_6; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_7(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_7 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_7; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_8(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_8 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_8; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_9(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_9 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_9; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_10(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_10 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_10; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_0_11(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result0 = hdr.fit.result0 + value1; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table route_0_11 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_0_11; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_0(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_0 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_0; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_1(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_1 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_1; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_2(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_2 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_2; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_3(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_3 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_3; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_4(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_4 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_4; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_5(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_5 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_5; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_6(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_6 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_6; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_7(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_7 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_7; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_8(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_8 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_8; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_9(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_9 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_9; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_10(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_10 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_10; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }
    action set_route_1_11(bit<32> value0, bit<32> value1) { hdr.fit.token = value0; hdr.fit.result1 = hdr.fit.result1 + value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table route_1_11 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_route_1_11; NoAction; }
        const default_action = NoAction();
        size = 32768;
    }

    apply {
        ig_tm_md.ucast_egress_port = ig_intr_md.ingress_port;
        if (hdr.fit.isValid()) {
            if (hdr.fit.branch == 0) {
                route_0_0.apply();
                route_0_1.apply();
                route_0_2.apply();
                route_0_3.apply();
                route_0_4.apply();
                route_0_5.apply();
                route_0_6.apply();
                route_0_7.apply();
                route_0_8.apply();
                route_0_9.apply();
                route_0_10.apply();
                route_0_11.apply();
            } else {
                route_1_0.apply();
                route_1_1.apply();
                route_1_2.apply();
                route_1_3.apply();
                route_1_4.apply();
                route_1_5.apply();
                route_1_6.apply();
                route_1_7.apply();
                route_1_8.apply();
                route_1_9.apply();
                route_1_10.apply();
                route_1_11.apply();
            }
        }
    }
}

control IngressDeparser(packet_out pkt, inout headers_t hdr, in metadata_t md,
                        in ingress_intrinsic_metadata_for_deparser_t ig_dprsr_md) {
    apply { pkt.emit(hdr); }
}

parser EgressParser(packet_in pkt, out headers_t hdr, out metadata_t md,
                    out egress_intrinsic_metadata_t eg_intr_md) {
    state start { pkt.extract(eg_intr_md); transition ethernet; }
    state ethernet {
        pkt.extract(hdr.ethernet);
        transition select(hdr.ethernet.ether_type) { 16w0x88b5: fit; default: accept; }
    }
    state fit { pkt.extract(hdr.fit); transition accept; }
}
control Egress(inout headers_t hdr, inout metadata_t md,
               in egress_intrinsic_metadata_t eg_intr_md,
               in egress_intrinsic_metadata_from_parser_t eg_prsr_md,
               inout egress_intrinsic_metadata_for_deparser_t eg_dprsr_md,
               inout egress_intrinsic_metadata_for_output_port_t eg_oport_md) {
    apply { }
}
control EgressDeparser(packet_out pkt, inout headers_t hdr, in metadata_t md,
                       in egress_intrinsic_metadata_for_deparser_t eg_dprsr_md) {
    apply { pkt.emit(hdr); }
}
Pipeline(IngressParser(), Ingress(), IngressDeparser(),
         EgressParser(), Egress(), EgressDeparser()) pipe;
Switch(pipe) main;

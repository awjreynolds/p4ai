// SPDX-License-Identifier: MIT
// Generated discovery candidate. Resource fit has not been established.
#include <core.p4>
#if __TARGET_TOFINO__ == 2
#include <t2na.p4>
#else
#include <tna.p4>
#endif

header ethernet_t { bit<48> dst; bit<48> src; bit<16> ether_type; }
header fit_t {
    bit<32> token;
    bit<48> tenant;
    bit<32> result0;
    bit<32> result1;
    bit<32> result2;
    bit<32> result3;
    bit<32> result4;
    bit<32> result5;
    bit<32> result6;
    bit<32> result7;
    bit<8> branch;
    bit<32> reserved;
}
struct headers_t { ethernet_t ethernet; fit_t fit; }
struct metadata_t { }

parser IngressParser(packet_in pkt, out headers_t hdr, out metadata_t md,
                     out ingress_intrinsic_metadata_t ig_intr_md) {
    state start {
        pkt.extract(ig_intr_md);
        transition select(ig_intr_md.resubmit_flag) { 0: port_metadata; default: reject; }
    }
    state port_metadata { pkt.advance(PORT_METADATA_SIZE); transition ethernet; }
    state ethernet {
        pkt.extract(hdr.ethernet);
        transition select(hdr.ethernet.ether_type) { 16w0x88b5: fit; default: accept; }
    }
    state fit { pkt.extract(hdr.fit); transition accept; }
}

control Ingress(inout headers_t hdr, inout metadata_t md,
                in ingress_intrinsic_metadata_t ig_intr_md,
                in ingress_intrinsic_metadata_from_parser_t ig_prsr_md,
                inout ingress_intrinsic_metadata_for_deparser_t ig_dprsr_md,
                inout ingress_intrinsic_metadata_for_tm_t ig_tm_md) {
    action set_policy_0(bit<16> value0) { hdr.fit.result2 = hdr.fit.result2 + (bit<32>)value0; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table policy_0 {
        key = { hdr.fit.result7 : exact; hdr.fit.tenant : exact; }
        actions = { set_policy_0; NoAction; }
        const default_action = NoAction();
        size = 131072;
    }
    action set_policy_1(bit<16> value0) { hdr.fit.result3 = hdr.fit.result3 + (bit<32>)value0; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table policy_1 {
        key = { hdr.fit.result7 : exact; hdr.fit.tenant : exact; }
        actions = { set_policy_1; NoAction; }
        const default_action = NoAction();
        size = 131072;
    }
    action set_policy_2(bit<16> value0) { hdr.fit.result4 = hdr.fit.result4 + (bit<32>)value0; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table policy_2 {
        key = { hdr.fit.result7 : exact; hdr.fit.tenant : exact; }
        actions = { set_policy_2; NoAction; }
        const default_action = NoAction();
        size = 131072;
    }
    action set_policy_3(bit<16> value0) { hdr.fit.result5 = hdr.fit.result5 + (bit<32>)value0; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table policy_3 {
        key = { hdr.fit.result7 : exact; hdr.fit.tenant : exact; }
        actions = { set_policy_3; NoAction; }
        const default_action = NoAction();
        size = 131072;
    }
    action set_policy_4(bit<16> value0) { hdr.fit.result6 = hdr.fit.result6 + (bit<32>)value0; }
                                                                                
                                                                                
    @pack(3)                                                                    
                                                                                
    table policy_4 {
        key = { hdr.fit.result7 : exact; hdr.fit.tenant : exact; }
        actions = { set_policy_4; NoAction; }
        const default_action = NoAction();
        size = 131072;
    }
    action set_update_0(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_0 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_0; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_1(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_1 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_1; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_2(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_2 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_2; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_3(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_3 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_3; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_4(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_4 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_4; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_5(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_5 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_5; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_6(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_6 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_6; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_7(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_7 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_7; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_8(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_8 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_8; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_9(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_9 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_9; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_10(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_10 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_10; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }
    action set_update_11(bit<16> value0, bit<16> value1) { hdr.fit.token = hdr.fit.token + (bit<32>)value0; hdr.fit.result0 = hdr.fit.result0 + (bit<32>)value1; }
                                                                                
                                                                                
                                                                                
                                                                                
    table update_11 {
        key = { hdr.fit.token : exact; hdr.fit.tenant : exact; }
        actions = { set_update_11; NoAction; }
        const default_action = NoAction();
        size = 8192;
    }

    apply {
        ig_tm_md.ucast_egress_port = ig_intr_md.ingress_port;
        if (hdr.fit.isValid()) {
            policy_0.apply();
            policy_1.apply();
            policy_2.apply();
            policy_3.apply();
            policy_4.apply();
            update_0.apply();
            update_1.apply();
            update_2.apply();
            update_3.apply();
            update_4.apply();
            update_5.apply();
            update_6.apply();
            update_7.apply();
            update_8.apply();
            update_9.apply();
            update_10.apply();
            update_11.apply();
        }
    }
}

control IngressDeparser(packet_out pkt, inout headers_t hdr, in metadata_t md,
                        in ingress_intrinsic_metadata_for_deparser_t ig_dprsr_md) {
    apply { pkt.emit(hdr); }
}

parser EgressParser(packet_in pkt, out headers_t hdr, out metadata_t md,
                    out egress_intrinsic_metadata_t eg_intr_md) {
    state start { pkt.extract(eg_intr_md); transition ethernet; }
    state ethernet {
        pkt.extract(hdr.ethernet);
        transition select(hdr.ethernet.ether_type) { 16w0x88b5: fit; default: accept; }
    }
    state fit { pkt.extract(hdr.fit); transition accept; }
}
control Egress(inout headers_t hdr, inout metadata_t md,
               in egress_intrinsic_metadata_t eg_intr_md,
               in egress_intrinsic_metadata_from_parser_t eg_prsr_md,
               inout egress_intrinsic_metadata_for_deparser_t eg_dprsr_md,
               inout egress_intrinsic_metadata_for_output_port_t eg_oport_md) {
    apply { }
}
control EgressDeparser(packet_out pkt, inout headers_t hdr, in metadata_t md,
                       in egress_intrinsic_metadata_for_deparser_t eg_dprsr_md) {
    apply { pkt.emit(hdr); }
}
Pipeline(IngressParser(), Ingress(), IngressDeparser(),
         EgressParser(), Egress(), EgressDeparser()) pipe;
Switch(pipe) main;
